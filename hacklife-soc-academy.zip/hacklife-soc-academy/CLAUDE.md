# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

**HackLife SOC Academy** is a professional cybersecurity learning platform with a futuristic "Obsidian Iron Man" design. The application teaches progression from complete beginner to expert SOC analyst across 4 phases (152 hours of world-class content):

- **Phase 0: Fondamentaux** (32h) — OS, networking, cryptography basics
- **Phase 1: SOC Foundations** (32h) — SIEM, log analysis, threat intelligence
- **Phase 2: SOC Analyst** (50h) — Splunk advanced, incident response, forensics
- **Phase 3: SOC Expert** (38h) — Threat hunting, malware analysis, purple team exercises

All content is in French and based on industry standards (SANS, BTL1, CompTIA, MITRE ATT&CK).

## Quick Start

```bash
# Install dependencies
npm install

# Run dev server on port 5174
npm run dev

# Build for production
npm build

# Preview production build
npm preview
```

## Tech Stack

- **React 18.3.1** with Vite as build tool
- **Tailwind CSS 3.4.14** for utility-first styling
- **PostCSS** with Autoprefixer for vendor prefixes
- **Vanilla CSS** for advanced animations and HUD effects
- **LocalStorage** for progress persistence

## Project Structure

```
hacklife-soc-academy/
├── index.html              # Entry HTML with all inline HUD/animation CSS
├── src/
│   ├── main.jsx           # React bootstrap
│   ├── App.jsx            # Main SPA component (hero, phases, courses, modals)
│   ├── curriculum.js      # Complete curriculum data (18 courses, 100+ modules)
│   └── index.css          # Tailwind imports
├── tailwind.config.js     # Custom colors, fonts, animations
├── vite.config.js         # Vite config with React plugin, port 5174
├── postcss.config.js      # PostCSS with tailwindcss + autoprefixer
└── .claude/launch.json    # Launch config for preview_start
```

## Design System

### Colors (Custom Tailwind Theme)
- `obsidian` (#060a12) — Main background
- `cyan` (#00d4ff) — Primary accent, HUD elements, text glow
- `gold` (#f5a623) — Phase 2 accent, alternative highlight
- `violet` (#bf5af2) — Phase 3 accent
- `emerald` (#00ff88) — Phase 0 accent
- `crimson` (#cc1a2f) — Alerts/warnings

### Fonts
- **JetBrains Mono** (300–700) — Code, UI labels, monospace text
- **Inter** (300–900) — Body, descriptions

### Key CSS Classes (in index.html)
- `.hud-grid` — Cyan grid background pattern (50px)
- `.hud-bracket` — Corner bracket decorations (::before ::after)
- `.glass` / `.glass-gold` / `.glass-violet` / `.glass-emerald` — Frosted glass cards with backdrop blur
- `.glow-cyan` / `.glow-gold` — Text shadow glow effects
- `.scan-line` — Animated full-viewport scan line (8s)
- `.pulse-dot` — Pulsing dot animation (2s)
- `.fade-up` / `.delay-1` through `.delay-4` — Staggered fade-in animations
- `.glitch` — Glitch text effect with data-text attribute
- `.modal-overlay` — Full-screen modal backdrop with blur

### Tailwind Custom Animations
- `scan` — 4s translateY loop
- `flicker` — 8s opacity flicker
- `float` — 6s translateY floating

## App Architecture

### src/App.jsx (Main Component)

**State Management:**
- `view` — Current view ('home' | 'courses' | 'phases')
- `selectedCourse` — Active course detail to display in modal
- `activePhase` — Filter courses by phase (0–3 or null for all)
- `search` — Search input for course filtering
- `activeTab` — Modal tab ('overview' | 'modules' | 'resources' | 'labs')
- `progress` — Object tracking completed modules per course (persisted in localStorage)

**Views:**

1. **Hero Section** — Full-screen intro with animated HUD
   - Glowing title with cyan text-shadow
   - Animated subtitle ("INITIALIZING...")
   - Stats grid (courses, modules, hours, phases)
   - Buttons to navigate to courses/phases views

2. **Phases Overview** — Phase cards with progress bars
   - Click to filter courses by phase
   - Progress calculation: completed modules ÷ total modules per phase
   - Color-coded per phase

3. **Courses Grid** — Filterable course cards
   - Search by title/tagline
   - Filter by phase (buttons)
   - Shows per-course progress
   - Click to open course detail modal

4. **Course Detail Modal** — Full course information
   - Four tabs: Overview, Modules, Resources, Labs
   - Overview: description, level, duration, objectives, skills
   - Modules: checkbox list with content and exercise types
   - Resources: tools/platforms, lab environment, certification
   - Labs: practical project list
   - Clicking a module toggles completion and updates localStorage

### src/curriculum.js (Data)

Exports:
- `COURSES` — Array of 18 course objects, each with:
  - `id`, `phase` (0–3), `title`, `tagline`, `level`, `duration`, `color`
  - `icon`, `desc`, `skills`, `prerequisites`, `objectives`
  - `modules` array (5–6 per course) with: `title`, `duration`, `type` (theory/lab/challenge/project), `content`
  - `resources`, `certification`, `labEnvironment`
- `PHASES` — Metadata for 4 phases (name, color, icon, hours)
- `TOTAL_HOURS` (152), `TOTAL_COURSES` (18)

## Key Features

### Progress Tracking
- Modules marked complete via checkbox in modal
- State stored in `localStorage['soc-progress']` as JSON object
- Key format: `"courseId-moduleTitle"`
- Progress bars update in real time across all views

### Glass Morphism UI
- All cards use `backdrop-filter: blur(20px)` + semi-transparent backgrounds
- Cyan borders at low opacity for subtle definition
- Glowing text effects via `text-shadow` with matching colors

### Responsive Design
- Uses Tailwind responsive utilities (`md:`, `lg:`)
- HUD hex decorations positioned absolutely
- Scans lines and animations fixed viewport

### Animations
- Scan line: infinite vertical traverse (8s)
- Text glow: CSS text-shadow, no JS
- Progress bars: smooth width transitions (500ms)
- Course cards: hover scale + translateY
- Fade-up: staggered entrance with delays (0.1–0.4s)

## Common Development Tasks

### Add a New Course

1. Edit `src/curriculum.js` — add to `COURSES` array:
   ```js
   {
     id: 'unique-id',
     phase: 2,
     title: 'Course Title',
     tagline: 'Short description.',
     level: 'Level',
     duration: '10h',
     color: '#00d4ff',
     icon: '📚',
     desc: '...',
     skills: [...],
     prerequisites: [...],
     objectives: [...],
     modules: [...],
     resources: [...],
     certification: '...',
     labEnvironment: '...'
   }
   ```
2. App will auto-render the course in the grid

### Adjust Colors

Edit `tailwind.config.js` theme.extend.colors or inline `style={{ color: '#...' }}` in App.jsx.

### Modify Animations

Edit keyframes in `index.html` `<style>` block or Tailwind config `theme.animation`.

### Update Progress Persistence

Toggle `localStorage` calls in `useEffect` in App.jsx. Current: full persistence, clear with DevTools.

## Testing

1. **UI/UX:** Open http://localhost:5174 → hero loads → buttons navigate → course cards appear → modal opens with all tabs
2. **Progress:** Check module in modal → refresh page → should persist
3. **Search:** Type in course search → grid filters in real time
4. **Phase Filter:** Click phase button → grid shows only that phase's courses

## Performance Considerations

- All 18 courses load client-side (no pagination)
- Curriculum data is ~50KB
- Progress object kept minimal (only completed modules, not full module data)
- Animations use CSS (GPU-accelerated)
- No external API calls

## Deployment

Build with `npm build` → outputs `/dist/` for static hosting.

**Note:** Ensure `base: '/'` in vite.config.js matches deployment path.

## Learning Resources Embedded

Curriculum covers:
- **Architecture:** Von Neumann model, CPU/memory, hypervisors
- **Networking:** OSI/TCP-IP, DNS, DHCP, Wireshark
- **Cryptography:** Symmetric/asymmetric, hashing, PKI, TLS
- **SOC:** SIEM, Splunk, log analysis, threat intelligence
- **Incident Response:** NIST framework, containment, forensics
- **Threat Hunting:** Behavioral analytics, YARA, ATT&CK simulation
- **Tools:** Splunk, Wireshark, Ghidra, Caldera, MISP, Maltego

Each course includes 5–6 modules mixing theory (90–120 min), labs, and projects.
