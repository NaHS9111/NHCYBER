/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        obsidian: '#060a12',
        navy: '#0a0e1a',
        cyan: { DEFAULT: '#00d4ff', dark: '#0099cc' },
        gold: { DEFAULT: '#f5a623', dark: '#c17d0a' },
        crimson: '#cc1a2f',
        violet: '#7c5cfc',
        emerald: { DEFAULT: '#00ff88', dark: '#00cc6a' },
      },
      fontFamily: {
        mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      backdropBlur: { xs: '2px' },
      animation: {
        'scan': 'scan 4s linear infinite',
        'pulse-slow': 'pulse 3s ease-in-out infinite',
        'flicker': 'flicker 8s linear infinite',
        'float': 'float 6s ease-in-out infinite',
      },
      keyframes: {
        scan: { '0%': { transform: 'translateY(-100%)' }, '100%': { transform: 'translateY(100vh)' } },
        flicker: { '0%,96%,100%': { opacity: 1 }, '97%': { opacity: 0.7 }, '98%': { opacity: 1 }, '99%': { opacity: 0.8 } },
        float: { '0%,100%': { transform: 'translateY(0px)' }, '50%': { transform: 'translateY(-12px)' } },
      },
    },
  },
  plugins: [],
}
