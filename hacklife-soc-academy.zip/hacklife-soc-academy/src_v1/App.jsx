import React, { useState, useEffect, useRef } from 'react'
import { COURSES } from './curriculum'
import { MODULE_CONTENT } from './content.js'

const PHASE_COLORS = ['#00ff88', '#00d4ff', '#f5a623', '#bf5af2']
const PHASE_NAMES = ['FONDAMENTAUX', 'SOC FOUNDATIONS', 'SOC ANALYST', 'SOC EXPERT']

const GESTURE_LABELS = [
  ['☝️', 'POINT', '— SÉLECTION'],
  ['✌️', 'PEACE', '— FOCUS'],
  ['✊', 'FIST', '— PAN (glisser)'],
  ['🤏', 'PINCH', '— ZOOM'],
  ['🖖', 'THREE', '— RESET VUE'],
  ['✋', 'OPEN', '— FERMER'],
]

const HAND_CONNECTIONS = [
  [0,1],[1,2],[2,3],[3,4],
  [0,5],[5,6],[6,7],[7,8],
  [5,9],[9,10],[10,11],[11,12],
  [9,13],[13,14],[14,15],[15,16],
  [13,17],[17,18],[18,19],[19,20],[0,17]
]

function createGraph(w, h) {
  const nodes = COURSES.map(c => ({
    id: c.id,
    label: c.title.includes(':') ? c.title.split(':').slice(1).join(':').trim() : c.title,
    phase: c.phase,
    course: c,
    x: w / 2 + (Math.random() - 0.5) * w * 0.55,
    y: h / 2 + (Math.random() - 0.5) * h * 0.45,
    vx: 0, vy: 0,
  }))

  const byPhase = [0, 1, 2, 3].map(p => nodes.filter(n => n.phase === p))
  const edges = []

  // Within-phase connections (chain)
  byPhase.forEach(group => {
    for (let i = 0; i < group.length - 1; i++) {
      edges.push({ source: group[i], target: group[i + 1] })
    }
  })

  // Cross-phase connections
  for (let p = 0; p < 3; p++) {
    const a = byPhase[p], b = byPhase[p + 1]
    const n = Math.min(a.length, b.length)
    for (let i = 0; i < n; i++) {
      edges.push({ source: a[i], target: b[i % b.length] })
    }
    // Extra cross connections
    if (a.length > 1 && b.length > 1) {
      edges.push({ source: a[a.length - 1], target: b[0] })
    }
  }

  return { nodes, edges }
}

function runForce(graph, w, h) {
  const { nodes, edges } = graph
  const alpha = 0.25
  const repulsion = 4000
  const springLen = 140
  const springK = 0.04
  const centerK = 0.006
  const damping = 0.86

  for (let i = 0; i < nodes.length; i++) {
    for (let j = i + 1; j < nodes.length; j++) {
      const dx = nodes[j].x - nodes[i].x || 0.01
      const dy = nodes[j].y - nodes[i].y || 0.01
      const d2 = dx * dx + dy * dy || 1
      const d = Math.sqrt(d2)
      const f = (repulsion / d2) * alpha
      const nx = dx / d, ny = dy / d
      nodes[i].vx -= nx * f; nodes[i].vy -= ny * f
      nodes[j].vx += nx * f; nodes[j].vy += ny * f
    }
  }

  edges.forEach(e => {
    const dx = e.target.x - e.source.x
    const dy = e.target.y - e.source.y
    const d = Math.sqrt(dx * dx + dy * dy) || 1
    const f = (d - springLen) * springK * alpha
    const nx = dx / d, ny = dy / d
    e.source.vx += nx * f; e.source.vy += ny * f
    e.target.vx -= nx * f; e.target.vy -= ny * f
  })

  const pad = 70
  nodes.forEach(n => {
    n.vx += (w / 2 - n.x) * centerK
    n.vy += (h / 2 - n.y) * centerK
    n.vx *= damping; n.vy *= damping
    n.x += n.vx; n.y += n.vy
    n.x = Math.max(pad, Math.min(w - pad, n.x))
    n.y = Math.max(pad, Math.min(h - pad, n.y))
  })
}

function renderGraph(ctx, graph, cursor, selectedId, view) {
  const { nodes, edges } = graph
  const { x: ox, y: oy, scale: sc } = view
  const tx = n => n.x * sc + ox
  const ty = n => n.y * sc + oy
  // cursor in graph-space for hit-test
  const gcx = cursor.x >= 0 ? (cursor.x - ox) / sc : -1
  const gcy = cursor.y >= 0 ? (cursor.y - oy) / sc : -1

  // Edges
  edges.forEach(e => {
    const sx = tx(e.source), sy = ty(e.source)
    const ex2 = tx(e.target), ey2 = ty(e.target)
    const d = Math.hypot(ex2 - sx, ey2 - sy)
    const op = Math.max(0.04, 0.28 - d / 1800)
    ctx.strokeStyle = `rgba(200,220,255,${op})`
    ctx.lineWidth = 0.5
    ctx.beginPath()
    ctx.moveTo(sx, sy)
    ctx.lineTo(ex2, ey2)
    ctx.stroke()
  })

  // Nodes
  nodes.forEach(n => {
    const color = PHASE_COLORS[n.phase]
    const isHovered = gcx >= 0 && Math.hypot(n.x - gcx, n.y - gcy) < 44 / sc
    const isSelected = n.id === selectedId
    const r = (isSelected ? 11 : isHovered ? 9 : 5) * Math.min(sc, 1.5)
    const sx = tx(n), sy = ty(n)

    if (isSelected || isHovered) {
      const grd = ctx.createRadialGradient(sx, sy, 0, sx, sy, 36 * sc)
      grd.addColorStop(0, color + '55')
      grd.addColorStop(1, 'transparent')
      ctx.fillStyle = grd
      ctx.beginPath()
      ctx.arc(sx, sy, 36 * sc, 0, Math.PI * 2)
      ctx.fill()
    }

    ctx.fillStyle = color
    ctx.shadowColor = color
    ctx.shadowBlur = isSelected ? 20 : isHovered ? 12 : 4
    ctx.beginPath()
    ctx.arc(sx, sy, r, 0, Math.PI * 2)
    ctx.fill()
    ctx.shadowBlur = 0

    if (isHovered || isSelected) {
      ctx.fillStyle = 'rgba(255,255,255,0.9)'
      ctx.font = `bold ${Math.round(11 * Math.min(sc, 1.4))}px "JetBrains Mono", monospace`
      ctx.textAlign = 'center'
      ctx.textBaseline = 'bottom'
      const lines = n.label.length > 22 ? [n.label.slice(0, 22), n.label.slice(22, 44)] : [n.label]
      lines.forEach((line, i) => {
        ctx.fillText(line, sx, sy - r - 6 - (lines.length - 1 - i) * 14)
      })
    }
  })
}

function renderHand(ctx, landmarks, w, h) {
  const px = lm => (1 - lm.x) * w
  const py = lm => lm.y * h

  ctx.strokeStyle = 'rgba(0,212,255,0.65)'
  ctx.lineWidth = 1.5
  HAND_CONNECTIONS.forEach(([s, e]) => {
    ctx.beginPath()
    ctx.moveTo(px(landmarks[s]), py(landmarks[s]))
    ctx.lineTo(px(landmarks[e]), py(landmarks[e]))
    ctx.stroke()
  })

  landmarks.forEach((lm, i) => {
    const x = px(lm), y = py(lm)
    ctx.fillStyle = i === 8 ? '#ff3bff' : '#00d4ff'
    ctx.beginPath()
    ctx.arc(x, y, i === 8 ? 5 : 3, 0, Math.PI * 2)
    ctx.fill()
  })
}

function renderCursor(ctx, x, y, gesture) {
  const color = gesture === 'POINT' ? '#ff3bff' : 'rgba(0,212,255,0.7)'
  ctx.strokeStyle = color
  ctx.lineWidth = 1.5
  ctx.beginPath()
  ctx.arc(x, y, 16, 0, Math.PI * 2)
  ctx.stroke()
  ctx.fillStyle = color.replace('0.7', '0.15').replace('#ff3bff', 'rgba(255,59,255,0.15)')
  ctx.fill()
}

// ─── Zoom HUD display ────────────────────────────────────────────────────────
function ZoomDisplay({ viewRef }) {
  const [scale, setScale] = useState(1)
  useEffect(() => {
    const id = setInterval(() => setScale(+(viewRef.current.scale.toFixed(2))), 100)
    return () => clearInterval(id)
  }, [viewRef])
  return (
    <div style={{
      color: 'rgba(0,212,255,0.35)', fontSize: 9, letterSpacing: 2,
      fontFamily: '"JetBrains Mono", monospace',
    }}>
      ZOOM {Math.round(scale * 100)}%
    </div>
  )
}

// ─── Obsidian Course Reader ───────────────────────────────────────────────────
function CourseReader({ course, onClose }) {
  const [activeModule, setActiveModule] = useState(0)
  const [activeSection, setActiveSection] = useState(null)
  const color = PHASE_COLORS[course.phase]
  const modules = course.modules || []
  const content = MODULE_CONTENT[course.id] || []

  const mod = modules[activeModule]
  const modContent = content[activeModule]

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 50,
      display: 'flex', fontFamily: '"JetBrains Mono", monospace',
      background: 'rgba(4,8,16,0.97)',
      backdropFilter: 'blur(24px)',
    }}>
      {/* ── LEFT SIDEBAR ── */}
      <div style={{
        width: 280, flexShrink: 0,
        borderRight: '1px solid rgba(0,212,255,0.08)',
        display: 'flex', flexDirection: 'column',
        background: 'rgba(6,10,18,0.6)',
        overflow: 'hidden',
      }}>
        {/* Header */}
        <div style={{ padding: '24px 20px 20px', borderBottom: '1px solid rgba(0,212,255,0.08)' }}>
          <div style={{ fontSize: 9, letterSpacing: 3, color: color, opacity: 0.7, marginBottom: 8 }}>
            PHASE {course.phase} — {PHASE_NAMES[course.phase]}
          </div>
          <div style={{ fontSize: 14, fontWeight: 700, color: '#e8f4f8', lineHeight: 1.4, marginBottom: 6 }}>
            {course.title}
          </div>
          <div style={{ fontSize: 9, color: 'rgba(0,212,255,0.4)', lineHeight: 1.6 }}>
            {course.duration} · {modules.length} modules · {course.level}
          </div>
        </div>

        {/* Module list */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '12px 0' }}>
          {modules.map((m, i) => {
            const hasContent = content[i]?.sections?.length > 0
            const isActive = i === activeModule
            return (
              <div
                key={i}
                onClick={() => { setActiveModule(i); setActiveSection(null) }}
                style={{
                  padding: '10px 20px', cursor: 'pointer',
                  borderLeft: `2px solid ${isActive ? color : 'transparent'}`,
                  background: isActive ? `${color}0a` : 'transparent',
                  transition: 'all 0.15s',
                }}
                onMouseEnter={e => { if (!isActive) e.currentTarget.style.background = 'rgba(0,212,255,0.04)' }}
                onMouseLeave={e => { if (!isActive) e.currentTarget.style.background = 'transparent' }}
              >
                <div style={{
                  fontSize: 10, fontWeight: isActive ? 700 : 400,
                  color: isActive ? color : 'rgba(232,244,248,0.6)',
                  lineHeight: 1.5, marginBottom: 4,
                }}>
                  {String(i + 1).padStart(2, '0')} {m.title}
                </div>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <span style={{ fontSize: 8, color: 'rgba(0,212,255,0.3)', letterSpacing: 1 }}>
                    {m.duration}
                  </span>
                  <span style={{
                    fontSize: 7, letterSpacing: 1, padding: '1px 5px', borderRadius: 2,
                    background: `${color}18`, color: `${color}88`,
                    border: `1px solid ${color}22`,
                  }}>
                    {m.type.toUpperCase()}
                  </span>
                  {hasContent && (
                    <span style={{ fontSize: 7, color: '#00ff8844', letterSpacing: 1 }}>●</span>
                  )}
                </div>
              </div>
            )
          })}
        </div>

        {/* Bottom stats */}
        <div style={{
          padding: '16px 20px',
          borderTop: '1px solid rgba(0,212,255,0.06)',
          display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8,
        }}>
          {course.skills?.slice(0, 4).map((s, i) => (
            <div key={i} style={{
              fontSize: 8, padding: '4px 6px', borderRadius: 2,
              background: `${color}0d`, color: `${color}77`,
              border: `1px solid ${color}1a`, letterSpacing: 0.5,
              overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
            }}>
              {s}
            </div>
          ))}
        </div>
      </div>

      {/* ── MAIN CONTENT AREA ── */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        {/* Topbar */}
        <div style={{
          height: 56, flexShrink: 0,
          borderBottom: '1px solid rgba(0,212,255,0.08)',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '0 28px',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
            <span style={{ fontSize: 11, color: color, fontWeight: 700, letterSpacing: 2 }}>
              {String(activeModule + 1).padStart(2, '0')} / {String(modules.length).padStart(2, '0')}
            </span>
            <span style={{ fontSize: 12, color: 'rgba(232,244,248,0.7)', fontWeight: 600 }}>
              {mod?.title}
            </span>
          </div>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            <button
              onClick={() => setActiveModule(i => Math.max(0, i - 1))}
              disabled={activeModule === 0}
              style={{
                background: 'transparent', border: '1px solid rgba(0,212,255,0.2)',
                color: activeModule === 0 ? 'rgba(0,212,255,0.2)' : '#00d4ff',
                padding: '5px 14px', borderRadius: 3, cursor: activeModule === 0 ? 'not-allowed' : 'pointer',
                fontSize: 10, letterSpacing: 1,
              }}
            >← PRÉC</button>
            <button
              onClick={() => setActiveModule(i => Math.min(modules.length - 1, i + 1))}
              disabled={activeModule === modules.length - 1}
              style={{
                background: 'transparent', border: '1px solid rgba(0,212,255,0.2)',
                color: activeModule === modules.length - 1 ? 'rgba(0,212,255,0.2)' : '#00d4ff',
                padding: '5px 14px', borderRadius: 3,
                cursor: activeModule === modules.length - 1 ? 'not-allowed' : 'pointer',
                fontSize: 10, letterSpacing: 1,
              }}
            >SUIV →</button>
            <button
              onClick={onClose}
              style={{
                background: 'transparent', border: `1px solid ${color}33`,
                color: `${color}88`, padding: '5px 16px', borderRadius: 3,
                cursor: 'pointer', fontSize: 10, letterSpacing: 2,
              }}
            >✕ FERMER</button>
          </div>
        </div>

        {/* Scrollable body */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '40px 48px 80px' }}>
          {/* Module header */}
          <div style={{ marginBottom: 40 }}>
            <div style={{ fontSize: 9, letterSpacing: 3, color: `${color}88`, marginBottom: 12 }}>
              MODULE {String(activeModule + 1).padStart(2, '0')} · {mod?.type?.toUpperCase()} · {mod?.duration}
            </div>
            <h1 style={{
              fontSize: 28, fontWeight: 900, color: '#e8f4f8', margin: 0, letterSpacing: 1,
              textShadow: `0 0 30px ${color}22`,
            }}>
              {mod?.title}
            </h1>
            <p style={{
              fontSize: 13, color: 'rgba(0,212,255,0.5)', marginTop: 12, lineHeight: 1.7,
              maxWidth: 680,
            }}>
              {mod?.content}
            </p>
            <div style={{ marginTop: 20, height: 1, background: `linear-gradient(90deg, ${color}44, transparent)` }} />
          </div>

          {modContent?.sections?.length > 0 ? (
            <>
              {/* Sections */}
              {modContent.sections.map((sec, si) => (
                <div key={si} style={{ marginBottom: 40 }}>
                  <h2
                    onClick={() => setActiveSection(activeSection === si ? null : si)}
                    style={{
                      fontSize: 15, fontWeight: 700, color: color, marginBottom: 14,
                      cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 10,
                      userSelect: 'none',
                    }}
                  >
                    <span style={{
                      fontSize: 10, opacity: 0.6,
                      transition: 'transform 0.2s',
                      display: 'inline-block',
                      transform: activeSection === si ? 'rotate(90deg)' : 'rotate(0deg)',
                    }}>▶</span>
                    {sec.heading}
                  </h2>

                  {(activeSection === null || activeSection === si) && (
                    <div>
                      <p style={{
                        fontSize: 13, color: 'rgba(232,244,248,0.75)', lineHeight: 1.9,
                        maxWidth: 720, whiteSpace: 'pre-wrap',
                      }}>
                        {sec.body}
                      </p>

                      {sec.code && (
                        <div style={{
                          margin: '20px 0', background: 'rgba(0,0,0,0.5)',
                          border: '1px solid rgba(0,212,255,0.12)', borderRadius: 4,
                          overflow: 'hidden',
                        }}>
                          <div style={{
                            padding: '6px 16px', background: 'rgba(0,212,255,0.06)',
                            borderBottom: '1px solid rgba(0,212,255,0.08)',
                            fontSize: 8, color: 'rgba(0,212,255,0.4)', letterSpacing: 2,
                          }}>
                            TERMINAL / CODE
                          </div>
                          <pre style={{
                            margin: 0, padding: '18px 20px',
                            fontSize: 11, color: '#00d4ff', lineHeight: 1.8,
                            overflowX: 'auto', whiteSpace: 'pre',
                          }}>
                            {sec.code}
                          </pre>
                        </div>
                      )}

                      {sec.tip && (
                        <div style={{
                          margin: '16px 0', padding: '14px 18px',
                          background: 'rgba(191,90,242,0.06)',
                          border: '1px solid rgba(191,90,242,0.2)',
                          borderLeft: '3px solid #bf5af2',
                          borderRadius: 4, fontSize: 12,
                          color: 'rgba(232,244,248,0.7)', lineHeight: 1.7,
                        }}>
                          <span style={{ color: '#bf5af2', fontWeight: 700, marginRight: 8 }}>💡</span>
                          {sec.tip}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}

              {/* Key Points */}
              {modContent.keyPoints?.length > 0 && (
                <div style={{
                  margin: '40px 0', padding: '24px 28px',
                  background: `${color}07`,
                  border: `1px solid ${color}22`, borderRadius: 6,
                }}>
                  <div style={{ fontSize: 9, letterSpacing: 3, color: `${color}88`, marginBottom: 16 }}>
                    POINTS CLÉS
                  </div>
                  {modContent.keyPoints.map((pt, i) => (
                    <div key={i} style={{
                      display: 'flex', gap: 12, marginBottom: 10,
                      fontSize: 12, color: 'rgba(232,244,248,0.8)', lineHeight: 1.6,
                    }}>
                      <span style={{ color, fontWeight: 700, flexShrink: 0 }}>▸</span>
                      <span>{pt}</span>
                    </div>
                  ))}
                </div>
              )}

              {/* Exercise */}
              {modContent.exercise && (
                <div style={{
                  margin: '32px 0', padding: '24px 28px',
                  background: 'rgba(0,255,136,0.05)',
                  border: '1px solid rgba(0,255,136,0.2)',
                  borderLeft: '3px solid #00ff88',
                  borderRadius: 6,
                }}>
                  <div style={{ fontSize: 9, letterSpacing: 3, color: '#00ff8888', marginBottom: 12 }}>
                    EXERCICE PRATIQUE
                  </div>
                  <p style={{ fontSize: 12, color: 'rgba(232,244,248,0.75)', lineHeight: 1.8, margin: 0 }}>
                    {modContent.exercise}
                  </p>
                </div>
              )}
            </>
          ) : (
            /* No content yet — show structured placeholder */
            <div style={{ color: 'rgba(0,212,255,0.3)', fontSize: 13, lineHeight: 2 }}>
              <div style={{ marginBottom: 32 }}>
                <div style={{ fontSize: 11, color: `${color}66`, letterSpacing: 2, marginBottom: 16 }}>
                  CONTENU EN COURS DE CHARGEMENT...
                </div>
                {[1, 2, 3].map(i => (
                  <div key={i} style={{ marginBottom: 24 }}>
                    <div style={{
                      height: 12, width: `${70 + i * 7}%`,
                      background: 'rgba(0,212,255,0.06)', borderRadius: 2, marginBottom: 8,
                    }} />
                    <div style={{
                      height: 8, width: '90%',
                      background: 'rgba(0,212,255,0.04)', borderRadius: 2, marginBottom: 6,
                    }} />
                    <div style={{
                      height: 8, width: '75%',
                      background: 'rgba(0,212,255,0.04)', borderRadius: 2,
                    }} />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Resources footer */}
          {course.resources?.length > 0 && (
            <div style={{ marginTop: 48, paddingTop: 28, borderTop: '1px solid rgba(0,212,255,0.08)' }}>
              <div style={{ fontSize: 9, letterSpacing: 3, color: 'rgba(0,212,255,0.3)', marginBottom: 16 }}>
                RESSOURCES & OUTILS
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                {course.resources.map((r, i) => (
                  <span key={i} style={{
                    fontSize: 10, padding: '5px 12px', borderRadius: 3,
                    background: 'rgba(0,212,255,0.05)',
                    border: '1px solid rgba(0,212,255,0.15)',
                    color: 'rgba(0,212,255,0.6)',
                  }}>
                    {r}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
// ─────────────────────────────────────────────────────────────────────────────

export default function App() {
  const videoRef = useRef(null)
  const canvasRef = useRef(null)
  const graphRef = useRef(null)
  const handsInstanceRef = useRef(null)
  const landmarksRef = useRef(null)
  const cursorRef = useRef({ x: -1, y: -1 })
  const rafRef = useRef(null)
  const simStepsRef = useRef(0)
  const lastDetectRef = useRef(0)
  const gestureRef = useRef({ name: '', duration: 0 })

  const viewRef = useRef({ x: 0, y: 0, scale: 1 })
  const prevPalmRef = useRef(null)       // for FIST-pan
  const prevPinchRef = useRef(null)      // for pinch-zoom distance

  const [camActive, setCamActive] = useState(true)
  const [gesture, setGesture] = useState('')
  const [handCount, setHandCount] = useState(0)
  const [selectedCourse, setSelectedCourse] = useState(null)
  const [readerOpen, setReaderOpen] = useState(false)
  const [stats, setStats] = useState({ nodes: 0, edges: 0, density: '0.000' })

  useEffect(() => {
    const canvas = canvasRef.current
    const W = window.innerWidth
    const H = window.innerHeight
    canvas.width = W
    canvas.height = H

    const graph = createGraph(W, H)
    graphRef.current = graph
    const n = graph.nodes.length
    const e = graph.edges.length
    setStats({ nodes: n, edges: e, density: (e / (n * (n - 1) / 2)).toFixed(3) })

    // Camera
    navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: W, height: H } })
      .then(stream => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream
          videoRef.current.play().then(loadMediaPipe).catch(loadMediaPipe)
        }
      })
      .catch(err => console.warn('Camera not available:', err))

    function loadMediaPipe() {
      if (window.Hands) { initHands(); return }
      const s = document.createElement('script')
      s.src = 'https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands.js'
      s.onload = () => setTimeout(initHands, 400)
      s.onerror = () => console.warn('MediaPipe failed to load')
      document.head.appendChild(s)
    }

    function initHands() {
      if (!window.Hands) { setTimeout(initHands, 100); return }
      const hands = new window.Hands({
        locateFile: f => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${f}`
      })
      hands.setOptions({ maxNumHands: 1, modelComplexity: 1, minDetectionConfidence: 0.65, minTrackingConfidence: 0.5 })
      hands.onResults(onHandResults)
      handsInstanceRef.current = hands
    }

    function onHandResults(results) {
      const lms = results.multiHandLandmarks
      if (lms && lms.length > 0) {
        const hand = lms[0]
        landmarksRef.current = hand
        setHandCount(lms.length)

        const W2 = canvas.width, H2 = canvas.height

        // Index finger tip as cursor (screen space, mirrored)
        const tipX = (1 - hand[8].x) * W2
        const tipY = hand[8].y * H2
        cursorRef.current = { x: tipX, y: tipY }

        // Palm center (wrist landmark 0, mirrored)
        const palmX = (1 - hand[0].x) * W2
        const palmY = hand[0].y * H2

        // Thumb-index pinch distance (normalised → pixels)
        const pinchDist = Math.hypot((hand[4].x - hand[8].x) * W2, (hand[4].y - hand[8].y) * H2)

        // Finger-up helpers
        const fu = (tip, pip) => hand[tip].y < hand[pip].y
        const idx = fu(8, 6), mid = fu(12, 10), ring = fu(16, 14), pink = fu(20, 18)
        const thumbOut = Math.abs(hand[4].x - hand[3].x) * W2 > 30

        // Pinch = thumb very close to index, others curled
        const isPinch = pinchDist < 40

        let g = ''
        if (isPinch)                              g = 'PINCH'
        else if (!idx && !mid && !ring && !pink)  g = 'FIST'
        else if (idx && !mid && !ring && !pink)   g = 'POINT'
        else if (idx && mid && !ring && !pink)    g = 'PEACE'
        else if (idx && mid && ring && !pink)     g = 'THREE'
        else if (idx && mid && ring && pink)      g = 'OPEN'

        // ── CONTINUOUS: FIST → PAN ──────────────────────────────────────────
        if (g === 'FIST') {
          const prev = prevPalmRef.current
          if (prev) {
            viewRef.current.x += palmX - prev.x
            viewRef.current.y += palmY - prev.y
          }
          prevPalmRef.current = { x: palmX, y: palmY }
        } else {
          prevPalmRef.current = null
        }

        // ── CONTINUOUS: PINCH → ZOOM ─────────────────────────────────────────
        if (g === 'PINCH') {
          const prevD = prevPinchRef.current
          if (prevD !== null) {
            const delta = pinchDist - prevD
            const factor = 1 + delta * 0.012
            const v = viewRef.current
            // Zoom toward cursor position
            const cx = tipX, cy = tipY
            v.scale = Math.max(0.3, Math.min(4, v.scale * factor))
            v.x = cx - (cx - v.x) * factor
            v.y = cy - (cy - v.y) * factor
          }
          prevPinchRef.current = pinchDist
        } else {
          prevPinchRef.current = null
        }

        // ── DISCRETE: THREE → RESET VIEW ────────────────────────────────────
        const gr = gestureRef.current
        if (g === gr.name) {
          gr.duration += 16
          if (gr.duration > 600) {
            triggerGesture(g, tipX, tipY)
            gr.duration = 0
          }
        } else {
          gr.name = g
          gr.duration = 0
        }

        setGesture(g)
      } else {
        landmarksRef.current = null
        cursorRef.current = { x: -1, y: -1 }
        setHandCount(0)
        setGesture('')
        gestureRef.current = { name: '', duration: 0 }
        prevPalmRef.current = null
        prevPinchRef.current = null
      }
    }

    function triggerGesture(g, x, y) {
      if (g === 'THREE') {
        // Reset view
        viewRef.current = { x: 0, y: 0, scale: 1 }
        return
      }
      if (g === 'OPEN') {
        setSelectedCourse(null)
        setReaderOpen(false)
        return
      }
      if (g === 'POINT' || g === 'PEACE') {
        const graph = graphRef.current
        if (!graph) return
        const v = viewRef.current
        // Convert screen cursor to graph space
        const gx = (x - v.x) / v.scale
        const gy = (y - v.y) / v.scale
        let closest = null, minD = 60 / v.scale
        graph.nodes.forEach(n => {
          const d = Math.hypot(n.x - gx, n.y - gy)
          if (d < minD) { minD = d; closest = n }
        })
        if (closest) setSelectedCourse(closest.course)
      }
    }

    // Main RAF loop
    function loop(ts) {
      const c = canvasRef.current
      if (!c) return
      const ctx = c.getContext('2d')
      ctx.clearRect(0, 0, c.width, c.height)

      const g = graphRef.current
      if (g) {
        if (simStepsRef.current < 400) {
          runForce(g, c.width, c.height)
          simStepsRef.current++
        }
        const cur = cursorRef.current
        const selId = selectedCourse?.id
        renderGraph(ctx, g, cur, selId, viewRef.current)
      }

      const lms = landmarksRef.current
      if (lms) renderHand(ctx, lms, c.width, c.height)

      const cur = cursorRef.current
      if (cur.x >= 0) renderCursor(ctx, cur.x, cur.y, gestureRef.current.name)

      if (handsInstanceRef.current && videoRef.current && videoRef.current.readyState >= 2 && ts - lastDetectRef.current > 33) {
        lastDetectRef.current = ts
        handsInstanceRef.current.send({ image: videoRef.current }).catch(() => {})
      }

      rafRef.current = requestAnimationFrame(loop)
    }

    rafRef.current = requestAnimationFrame(loop)

    function onResize() {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
      graphRef.current = createGraph(window.innerWidth, window.innerHeight)
      simStepsRef.current = 0
    }

    function onCanvasClick(e) {
      const g = graphRef.current
      if (!g) return
      const rect = canvas.getBoundingClientRect()
      const mx = e.clientX - rect.left
      const my = e.clientY - rect.top
      const v = viewRef.current
      const gx = (mx - v.x) / v.scale
      const gy = (my - v.y) / v.scale
      let closest = null, minD = 50 / v.scale
      g.nodes.forEach(n => {
        const d = Math.hypot(n.x - gx, n.y - gy)
        if (d < minD) { minD = d; closest = n }
      })
      if (closest) setSelectedCourse(closest.course)
      else setSelectedCourse(null)
    }

    // Mouse wheel zoom
    function onWheel(e) {
      e.preventDefault()
      const v = viewRef.current
      const rect = canvas.getBoundingClientRect()
      const mx = e.clientX - rect.left
      const my = e.clientY - rect.top
      const factor = e.deltaY < 0 ? 1.1 : 0.9
      v.scale = Math.max(0.3, Math.min(4, v.scale * factor))
      v.x = mx - (mx - v.x) * factor
      v.y = my - (my - v.y) * factor
    }

    window.addEventListener('resize', onResize)
    canvas.addEventListener('click', onCanvasClick)
    canvas.addEventListener('wheel', onWheel, { passive: false })

    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
      window.removeEventListener('resize', onResize)
      canvas.removeEventListener('click', onCanvasClick)
      canvas.removeEventListener('wheel', onWheel)
    }
  }, [])

  // Re-render graph when selectedCourse changes (to update highlight)
  useEffect(() => {
    if (graphRef.current) {
      const canvas = canvasRef.current
      const ctx = canvas.getContext('2d')
      renderGraph(ctx, graphRef.current, cursorRef.current, selectedCourse?.id, viewRef.current)
    }
  }, [selectedCourse])

  return (
    <div style={{ position: 'fixed', inset: 0, background: '#060a12', overflow: 'hidden', fontFamily: '"JetBrains Mono", monospace' }}>

      {/* Camera background */}
      <video
        ref={videoRef}
        autoPlay muted playsInline
        style={{
          position: 'absolute', inset: 0,
          width: '100%', height: '100%',
          objectFit: 'cover',
          transform: 'scaleX(-1)',
          opacity: camActive ? 0.65 : 0,
          transition: 'opacity 0.5s'
        }}
      />

      {/* Dark gradient overlay */}
      <div style={{
        position: 'absolute', inset: 0,
        background: 'radial-gradient(ellipse at center, rgba(6,10,18,0.3) 0%, rgba(6,10,18,0.7) 100%)'
      }} />

      {/* Vignette */}
      <div style={{
        position: 'absolute', inset: 0,
        boxShadow: 'inset 0 0 120px rgba(0,0,0,0.6)',
        pointerEvents: 'none'
      }} />

      {/* Graph + hands canvas */}
      <canvas
        ref={canvasRef}
        style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', cursor: 'crosshair' }}
      />

      {/* ── TOP LEFT: Branding + Stats ── */}
      <div style={{ position: 'absolute', top: 28, left: 28, zIndex: 10 }}>
        <div style={{
          fontSize: 22, fontWeight: 900, letterSpacing: 10, color: '#00d4ff',
          textShadow: '0 0 24px rgba(0,212,255,0.8), 0 0 48px rgba(0,212,255,0.3)',
          marginBottom: 12
        }}>
          SOC<span style={{ color: '#bf5af2', margin: '0 4px' }}>·</span>ACADEMY
        </div>
        <div style={{ fontSize: 10, color: 'rgba(0,212,255,0.45)', lineHeight: 2, letterSpacing: 1 }}>
          <div>{stats.nodes} NOEUDS</div>
          <div>{stats.edges} CONNEXIONS</div>
          <div>{stats.density} DENSITÉ</div>
        </div>
      </div>

      {/* ── TOP CENTER: Toggle button ── */}
      <button
        onClick={() => setCamActive(v => !v)}
        style={{
          position: 'absolute', top: 28, left: '50%', transform: 'translateX(-50%)',
          zIndex: 10, background: 'transparent',
          border: `1px solid rgba(0,212,255,${camActive ? 0.6 : 0.3})`,
          color: camActive ? '#00d4ff' : 'rgba(0,212,255,0.4)',
          padding: '6px 22px', borderRadius: 20, fontSize: 10, letterSpacing: 3,
          cursor: 'pointer', transition: 'all 0.3s',
          boxShadow: camActive ? '0 0 15px rgba(0,212,255,0.2)' : 'none'
        }}
      >
        {camActive ? 'DÉSACTIVER' : 'ACTIVER'}
      </button>

      {/* ── TOP RIGHT: Gesture + zoom indicator ── */}
      <div style={{ position: 'absolute', top: 28, right: 28, zIndex: 10, textAlign: 'right' }}>
        {gesture && (
          <div style={{
            color: gesture === 'PINCH' ? '#f5a623' : gesture === 'FIST' ? '#00ff88' : '#bf5af2',
            fontSize: 12, letterSpacing: 3, marginBottom: 6,
            textShadow: '0 0 12px currentColor',
            fontFamily: '"JetBrains Mono", monospace',
          }}>
            {gesture === 'PINCH' ? '🤏 ZOOM' : gesture === 'FIST' ? '✊ PAN' : gesture === 'THREE' ? '🖖 RESET' : gesture}
          </div>
        )}
        {handCount > 0 && (
          <div style={{ color: 'rgba(0,212,255,0.4)', fontSize: 9, letterSpacing: 2, marginBottom: 4,
            fontFamily: '"JetBrains Mono", monospace' }}>
            {handCount} MAIN{handCount > 1 ? 'S' : ''}
          </div>
        )}
        <ZoomDisplay viewRef={viewRef} />
      </div>

      {/* ── LEFT: Gesture guide ── */}
      <div style={{
        position: 'absolute', top: '50%', left: 28, transform: 'translateY(-50%)',
        zIndex: 10, borderLeft: '1px solid rgba(0,212,255,0.15)',
        paddingLeft: 14, display: 'flex', flexDirection: 'column', gap: 10
      }}>
        {GESTURE_LABELS.map(([icon, key, label]) => (
          <div key={key} style={{
            display: 'flex', alignItems: 'center', gap: 8, fontSize: 10,
            color: gesture === key ? '#00d4ff' : 'rgba(0,212,255,0.35)',
            transition: 'color 0.2s', letterSpacing: 1,
            textShadow: gesture === key ? '0 0 8px rgba(0,212,255,0.6)' : 'none'
          }}>
            <span style={{ fontSize: 13 }}>{icon}</span>
            <span style={{ fontWeight: gesture === key ? 700 : 400 }}>{key}</span>
            <span style={{ opacity: 0.6 }}>{label}</span>
          </div>
        ))}
      </div>

      {/* ── BOTTOM RIGHT: Phase legend ── */}
      <div style={{
        position: 'absolute', bottom: 28, left: 28, zIndex: 10,
        display: 'flex', flexDirection: 'column', gap: 6
      }}>
        {PHASE_COLORS.map((color, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 9, letterSpacing: 1 }}>
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: color, boxShadow: `0 0 6px ${color}` }} />
            <span style={{ color: `${color}99` }}>PHASE {i} — {PHASE_NAMES[i]}</span>
          </div>
        ))}
      </div>

      {/* ── NODE PREVIEW CARD ── */}
      {selectedCourse && !readerOpen && (() => {
        const c = selectedCourse
        const col = PHASE_COLORS[c.phase]
        return (
          <div style={{
            position: 'absolute', bottom: 28, right: 28, zIndex: 20,
            width: 310, background: 'rgba(5,9,18,0.94)',
            border: `1px solid ${col}33`, borderRadius: 6,
            backdropFilter: 'blur(20px)',
            boxShadow: `0 0 40px ${col}12`,
            overflow: 'hidden',
          }}>
            {/* Color band */}
            <div style={{ height: 3, background: `linear-gradient(90deg, ${col}, transparent)` }} />

            <div style={{ padding: '18px 20px 16px' }}>
              <div style={{ fontSize: 8, letterSpacing: 2, color: `${col}88`, marginBottom: 8 }}>
                PHASE {c.phase} — {PHASE_NAMES[c.phase]}
              </div>
              <div style={{ fontSize: 14, fontWeight: 700, color: '#e8f4f8', marginBottom: 4, lineHeight: 1.3 }}>
                {c.title}
              </div>
              <div style={{ fontSize: 10, color: 'rgba(0,212,255,0.45)', marginBottom: 16, lineHeight: 1.6 }}>
                {c.tagline}
              </div>

              <div style={{
                display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 6,
                paddingBottom: 16, borderBottom: `1px solid ${col}18`, marginBottom: 14,
              }}>
                {[['MODULES', c.modules?.length], ['DURÉE', c.duration], ['NIVEAU', c.level?.slice(0,3)], ['PHASE', c.phase]].map(([k, v]) => (
                  <div key={k} style={{ textAlign: 'center' }}>
                    <div style={{ fontSize: 7, color: 'rgba(0,212,255,0.25)', letterSpacing: 1, marginBottom: 3 }}>{k}</div>
                    <div style={{ fontSize: 13, fontWeight: 700, color: col }}>{v}</div>
                  </div>
                ))}
              </div>

              <div style={{ display: 'flex', gap: 8 }}>
                <button
                  onClick={() => setReaderOpen(true)}
                  style={{
                    flex: 1, padding: '9px 0', borderRadius: 3, cursor: 'pointer',
                    background: `${col}18`, border: `1px solid ${col}55`,
                    color: col, fontSize: 9, fontWeight: 700, letterSpacing: 2,
                    fontFamily: '"JetBrains Mono", monospace',
                    transition: 'all 0.2s',
                  }}
                  onMouseEnter={e => { e.currentTarget.style.background = `${col}28` }}
                  onMouseLeave={e => { e.currentTarget.style.background = `${col}18` }}
                >
                  OUVRIR LE COURS
                </button>
                <button
                  onClick={() => setSelectedCourse(null)}
                  style={{
                    padding: '9px 14px', borderRadius: 3, cursor: 'pointer',
                    background: 'transparent', border: '1px solid rgba(0,212,255,0.15)',
                    color: 'rgba(0,212,255,0.4)', fontSize: 9, letterSpacing: 1,
                    fontFamily: '"JetBrains Mono", monospace',
                  }}
                >
                  ✕
                </button>
              </div>
            </div>
          </div>
        )
      })()}

      {/* ── FULL COURSE READER ── */}
      {selectedCourse && readerOpen && (
        <CourseReader
          course={selectedCourse}
          onClose={() => { setReaderOpen(false); setSelectedCourse(null) }}
        />
      )}

      {/* Scan line */}
      <div style={{
        position: 'absolute', left: 0, right: 0, height: 1, zIndex: 5,
        background: 'linear-gradient(90deg, transparent 0%, rgba(0,212,255,0.25) 50%, transparent 100%)',
        animation: 'scan 8s linear infinite',
        pointerEvents: 'none'
      }} />
    </div>
  )
}
