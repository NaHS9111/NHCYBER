import React, { useState, useEffect, useRef } from 'react'
import { COURSES } from './curriculum'
import { MODULE_CONTENT } from './content.js'

// ─── Constants ────────────────────────────────────────────────────────────────
const PHASE_COLORS  = ['#00ff88', '#00d4ff', '#f5a623', '#bf5af2']
const PHASE_NAMES   = ['FONDAMENTAUX', 'SOC FOUNDATIONS', 'SOC ANALYST', 'SOC EXPERT']
const HAND_CONN     = [[0,1],[1,2],[2,3],[3,4],[0,5],[5,6],[6,7],[7,8],[5,9],[9,10],[10,11],[11,12],[9,13],[13,14],[14,15],[15,16],[13,17],[17,18],[18,19],[19,20],[0,17]]

// ─── Graph builder ────────────────────────────────────────────────────────────
function createGraph(W, H) {
  const nodes = COURSES.map(c => ({
    id: c.id,
    label: c.title.includes(':') ? c.title.split(':').slice(1).join(':').trim() : c.title,
    phase: c.phase, course: c,
    x: W/2 + (Math.random()-.5)*W*.55,
    y: H/2 + (Math.random()-.5)*H*.45,
    z: (Math.random()-.5)*120,
    vx:0, vy:0, vz:0,
    pulse: Math.random()*Math.PI*2,   // offset for breathing anim
  }))
  const byPhase = [0,1,2,3].map(p => nodes.filter(n=>n.phase===p))
  const edges = []
  byPhase.forEach(group => { for(let i=0;i<group.length-1;i++) edges.push({source:group[i],target:group[i+1],particles:[]}) })
  for(let p=0;p<3;p++){
    const a=byPhase[p], b=byPhase[p+1], n=Math.min(a.length,b.length)
    for(let i=0;i<n;i++) edges.push({source:a[i],target:b[i%b.length],particles:[]})
    if(a.length>1&&b.length>1) edges.push({source:a[a.length-1],target:b[0],particles:[]})
  }
  return {nodes,edges}
}

// ─── Force simulation ─────────────────────────────────────────────────────────
function runForce(graph, W, H) {
  const {nodes,edges}=graph
  const a=.22, rep=3800, slen=145, sk=.038, ck=.005, damp=.87
  for(let i=0;i<nodes.length;i++){
    for(let j=i+1;j<nodes.length;j++){
      const dx=nodes[j].x-nodes[i].x||.01, dy=nodes[j].y-nodes[i].y||.01
      const d2=dx*dx+dy*dy||1, d=Math.sqrt(d2), f=(rep/d2)*a, nx=dx/d, ny=dy/d
      nodes[i].vx-=nx*f; nodes[i].vy-=ny*f
      nodes[j].vx+=nx*f; nodes[j].vy+=ny*f
    }
  }
  edges.forEach(e=>{
    const dx=e.target.x-e.source.x, dy=e.target.y-e.source.y
    const d=Math.sqrt(dx*dx+dy*dy)||1, f=(d-slen)*sk*a, nx=dx/d, ny=dy/d
    e.source.vx+=nx*f; e.source.vy+=ny*f
    e.target.vx-=nx*f; e.target.vy-=ny*f
  })
  const pad=70
  nodes.forEach(n=>{
    n.vx+=(W/2-n.x)*ck; n.vy+=(H/2-n.y)*ck
    n.vx*=damp; n.vy*=damp; n.x+=n.vx; n.y+=n.vy
    n.x=Math.max(pad,Math.min(W-pad,n.x)); n.y=Math.max(pad,Math.min(H-pad,n.y))
  })
}

// ─── Canvas Rendering ─────────────────────────────────────────────────────────
function render(ctx, graph, cursor, selectedId, view, ts, trailRef) {
  const {nodes,edges}=graph
  const {x:ox,y:oy,scale:sc}=view
  const W=ctx.canvas.width, H=ctx.canvas.height
  const tx=n=>n.x*sc+ox, ty=n=>n.y*sc+oy
  const gcx=cursor.x>=0?(cursor.x-ox)/sc:-1
  const gcy=cursor.y>=0?(cursor.y-oy)/sc:-1

  // ── Edges with flowing particles ──────────────────────────────────────────
  edges.forEach(e=>{
    const sx=tx(e.source),sy=ty(e.source),ex=tx(e.target),ey=ty(e.target)
    const d=Math.hypot(ex-sx,ey-sy)
    const op=Math.max(.04,.22-d/2000)
    // Base line
    ctx.strokeStyle=`rgba(180,210,255,${op})`
    ctx.lineWidth=.5
    ctx.beginPath(); ctx.moveTo(sx,sy); ctx.lineTo(ex,ey); ctx.stroke()
    // Spawn & advance particles
    if(Math.random()<.04) e.particles.push({t:0,speed:.003+Math.random()*.004})
    e.particles=e.particles.filter(p=>{
      p.t+=p.speed
      if(p.t>1) return false
      const px2=sx+(ex-sx)*p.t, py2=sy+(ey-sy)*p.t
      const alpha=Math.sin(p.t*Math.PI)*.85
      ctx.fillStyle=`rgba(0,212,255,${alpha})`
      ctx.beginPath(); ctx.arc(px2,py2,1.5*sc,0,Math.PI*2); ctx.fill()
      return true
    })
  })

  // ── Nodes ─────────────────────────────────────────────────────────────────
  nodes.forEach(n=>{
    n.pulse+=.018
    const color=PHASE_COLORS[n.phase]
    const isHov=gcx>=0&&Math.hypot(n.x-gcx,n.y-gcy)<44/sc
    const isSel=n.id===selectedId
    const breathe=1+Math.sin(n.pulse)*.12
    const r=(isSel?13:isHov?10:5)*Math.min(sc,1.6)*breathe

    // 3D depth tint (z ∈ [-120,120] → slight scale+alpha)
    const depthAlpha=.7+(n.z+120)/240*.3

    // Outer glow ring
    if(isHov||isSel){
      const ringR=(isSel?42:34)*sc
      const grd=ctx.createRadialGradient(tx(n),ty(n),r*.5,tx(n),ty(n),ringR)
      grd.addColorStop(0,color+'44')
      grd.addColorStop(.6,color+'18')
      grd.addColorStop(1,'transparent')
      ctx.fillStyle=grd
      ctx.beginPath(); ctx.arc(tx(n),ty(n),ringR,0,Math.PI*2); ctx.fill()
      // Animated ring stroke
      const ringAlpha=.4+Math.sin(ts*.003)*.3
      ctx.strokeStyle=color+Math.round(ringAlpha*255).toString(16).padStart(2,'0')
      ctx.lineWidth=1
      ctx.beginPath(); ctx.arc(tx(n),ty(n),(ringR*.85),0,Math.PI*2); ctx.stroke()
    }

    // Node fill with glow
    ctx.globalAlpha=depthAlpha
    ctx.shadowColor=color; ctx.shadowBlur=isSel?28:isHov?16:6
    ctx.fillStyle=color
    ctx.beginPath(); ctx.arc(tx(n),ty(n),r,0,Math.PI*2); ctx.fill()
    ctx.shadowBlur=0; ctx.globalAlpha=1

    // Label
    if(isHov||isSel){
      const fSize=Math.round(11*Math.min(sc,1.5))
      ctx.fillStyle='rgba(255,255,255,.92)'
      ctx.font=`700 ${fSize}px "JetBrains Mono",monospace`
      ctx.textAlign='center'; ctx.textBaseline='bottom'
      const lines=n.label.length>22?[n.label.slice(0,22),n.label.slice(22,44)]:[n.label]
      lines.forEach((line,i)=>ctx.fillText(line,tx(n),ty(n)-r-8-(lines.length-1-i)*14))
    }
  })

  // ── Hand cursor trail ──────────────────────────────────────────────────────
  const trail=trailRef.current
  if(cursor.x>=0){
    trail.push({x:cursor.x,y:cursor.y,ts})
    if(trail.length>28) trail.shift()
    trail.forEach((pt,i)=>{
      const age=(ts-pt.ts)/320
      if(age>1) return
      const a=(1-age)*.7*(i/trail.length)
      ctx.fillStyle=`rgba(255,59,255,${a})`
      ctx.beginPath(); ctx.arc(pt.x,pt.y,3*(1-age)*sc,0,Math.PI*2); ctx.fill()
    })
    // Cursor ring
    const cr=18
    ctx.strokeStyle='rgba(255,59,255,.8)'
    ctx.lineWidth=1.5
    ctx.beginPath(); ctx.arc(cursor.x,cursor.y,cr,0,Math.PI*2); ctx.stroke()
    ctx.fillStyle='rgba(255,59,255,.12)'
    ctx.fill()
  } else {
    trailRef.current=[]
  }
}

function renderHand(ctx, landmarks, W, H, gesture) {
  const px=lm=>(1-lm.x)*W, py=lm=>lm.y*H
  const isPinch=gesture==='PINCH'
  const lineColor=isPinch?'rgba(245,166,35,.7)':'rgba(0,212,255,.65)'
  ctx.strokeStyle=lineColor; ctx.lineWidth=1.5
  HAND_CONN.forEach(([s,e])=>{
    ctx.beginPath(); ctx.moveTo(px(landmarks[s]),py(landmarks[s])); ctx.lineTo(px(landmarks[e]),py(landmarks[e])); ctx.stroke()
  })
  landmarks.forEach((lm,i)=>{
    const x=px(lm),y=py(lm)
    const isTip=[4,8,12,16,20].includes(i)
    ctx.fillStyle=i===8?'#ff3bff':isTip?'#00d4ff':'rgba(0,212,255,.5)'
    ctx.beginPath(); ctx.arc(x,y,isTip?4:2.5,0,Math.PI*2); ctx.fill()
    if(isTip){
      ctx.strokeStyle='rgba(0,212,255,.25)'; ctx.lineWidth=1
      ctx.beginPath(); ctx.arc(x,y,8,0,Math.PI*2); ctx.stroke()
    }
  })
}

// ─── Zoom display ─────────────────────────────────────────────────────────────
function ZoomDisplay({viewRef}){
  const [sc,setSc]=useState(1)
  useEffect(()=>{const id=setInterval(()=>setSc(+(viewRef.current.scale.toFixed(2))),120);return()=>clearInterval(id)},[])
  return <div style={{color:'rgba(0,212,255,.3)',fontSize:9,letterSpacing:2,fontFamily:'"JetBrains Mono",monospace'}}>ZOOM {Math.round(sc*100)}%</div>
}

// ─── Course Reader ─────────────────────────────────────────────────────────────
function CourseReader({course,onClose}){
  const [activeMod,setActiveMod]=useState(0)
  const [openSec,setOpenSec]=useState(null)
  const col=PHASE_COLORS[course.phase]
  const mods=course.modules||[]
  const content=MODULE_CONTENT[course.id]||[]
  const mod=mods[activeMod]
  const mc=content[activeMod]

  return(
    <div style={{position:'fixed',inset:0,zIndex:60,display:'flex',fontFamily:'"JetBrains Mono",monospace',background:'rgba(2,5,12,.97)',backdropFilter:'blur(30px)',animation:'fadeIn .3s ease'}}>
      <style>{`
        @keyframes fadeIn{from{opacity:0;transform:scale(.98)}to{opacity:1;transform:scale(1)}}
        @keyframes slideIn{from{opacity:0;transform:translateX(-16px)}to{opacity:1;transform:translateX(0)}}
        @keyframes shimmer{0%{background-position:200% center}100%{background-position:-200% center}}
        .mod-item:hover{background:rgba(0,212,255,.05)!important}
        .sec-body{animation:slideIn .2s ease}
        ::-webkit-scrollbar{width:4px;background:transparent}
        ::-webkit-scrollbar-thumb{background:rgba(0,212,255,.2);border-radius:2px}
      `}</style>

      {/* Sidebar */}
      <div style={{width:268,flexShrink:0,borderRight:`1px solid rgba(0,212,255,.07)`,display:'flex',flexDirection:'column',background:'rgba(4,8,18,.6)',overflow:'hidden'}}>
        <div style={{padding:'26px 20px 18px',borderBottom:`1px solid ${col}18`}}>
          <div style={{fontSize:8,letterSpacing:3,color:`${col}88`,marginBottom:8}}>{course.icon} PHASE {course.phase}</div>
          <div style={{fontSize:13,fontWeight:700,color:'#e8f4f8',lineHeight:1.4,marginBottom:4}}>{course.title}</div>
          <div style={{fontSize:9,color:'rgba(0,212,255,.35)',lineHeight:1.8}}>
            {course.duration} · {mods.length} modules · {course.level}
          </div>
        </div>
        <div style={{flex:1,overflowY:'auto',padding:'8px 0'}}>
          {mods.map((m,i)=>{
            const done=!!content[i]?.sections?.length
            const active=i===activeMod
            return(
              <div key={i} className="mod-item" onClick={()=>{setActiveMod(i);setOpenSec(null)}}
                style={{padding:'11px 18px',cursor:'pointer',borderLeft:`2px solid ${active?col:'transparent'}`,background:active?`${col}0c`:'transparent',transition:'all .15s'}}>
                <div style={{fontSize:10,fontWeight:active?700:400,color:active?col:'rgba(232,244,248,.5)',lineHeight:1.5,marginBottom:3}}>
                  {String(i+1).padStart(2,'0')} {m.title}
                </div>
                <div style={{display:'flex',gap:8,alignItems:'center'}}>
                  <span style={{fontSize:8,color:'rgba(0,212,255,.25)',letterSpacing:1}}>{m.duration}</span>
                  <span style={{fontSize:7,padding:'1px 5px',borderRadius:2,background:`${col}15`,color:`${col}77`,border:`1px solid ${col}22`}}>{m.type.toUpperCase()}</span>
                  {done&&<span style={{fontSize:8,color:'#00ff8866'}}>●</span>}
                </div>
              </div>
            )
          })}
        </div>
        <div style={{padding:'14px 18px',borderTop:`1px solid rgba(0,212,255,.06)`,display:'flex',flexWrap:'wrap',gap:6}}>
          {course.skills?.slice(0,6).map((s,i)=>(
            <span key={i} style={{fontSize:8,padding:'3px 7px',borderRadius:2,background:`${col}0e`,color:`${col}66`,border:`1px solid ${col}18`,overflow:'hidden',maxWidth:110,textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{s}</span>
          ))}
        </div>
      </div>

      {/* Main */}
      <div style={{flex:1,display:'flex',flexDirection:'column',overflow:'hidden'}}>
        {/* Topbar */}
        <div style={{height:54,flexShrink:0,borderBottom:`1px solid rgba(0,212,255,.07)`,display:'flex',alignItems:'center',justifyContent:'space-between',padding:'0 28px',background:'rgba(4,8,18,.4)'}}>
          <div style={{display:'flex',alignItems:'center',gap:14}}>
            <span style={{fontSize:10,color:`${col}88`,letterSpacing:2}}>{String(activeMod+1).padStart(2,'0')}/{String(mods.length).padStart(2,'0')}</span>
            <span style={{width:1,height:16,background:'rgba(0,212,255,.15)'}}/>
            <span style={{fontSize:12,color:'rgba(232,244,248,.8)',fontWeight:600}}>{mod?.title}</span>
          </div>
          <div style={{display:'flex',gap:8}}>
            {[['← PRÉC',()=>setActiveMod(i=>Math.max(0,i-1)),activeMod===0],
              ['SUIV →',()=>setActiveMod(i=>Math.min(mods.length-1,i+1)),activeMod===mods.length-1]].map(([label,fn,dis])=>(
              <button key={label} onClick={fn} disabled={dis} style={{background:'transparent',border:'1px solid rgba(0,212,255,.2)',color:dis?'rgba(0,212,255,.2)':'#00d4ff',padding:'5px 14px',borderRadius:3,fontSize:9,letterSpacing:1,cursor:dis?'not-allowed':'pointer',transition:'all .2s'}}>
                {label}
              </button>
            ))}
            <button onClick={onClose} style={{background:'transparent',border:`1px solid ${col}33`,color:`${col}88`,padding:'5px 18px',borderRadius:3,fontSize:9,letterSpacing:2,cursor:'pointer',transition:'all .2s'}}>✕ FERMER</button>
          </div>
        </div>

        {/* Body */}
        <div style={{flex:1,overflowY:'auto',padding:'44px 52px 80px'}}>
          {/* Module header */}
          <div style={{marginBottom:44}}>
            <div style={{fontSize:8,letterSpacing:3,color:`${col}77`,marginBottom:10}}>MODULE {String(activeMod+1).padStart(2,'0')} · {mod?.type?.toUpperCase()} · {mod?.duration}</div>
            <h1 style={{fontSize:30,fontWeight:900,color:'#f0f8ff',margin:'0 0 14px',letterSpacing:.5,lineHeight:1.2}}>{mod?.title}</h1>
            <p style={{fontSize:13,color:'rgba(0,212,255,.45)',margin:0,lineHeight:1.8,maxWidth:680}}>{mod?.content}</p>
            <div style={{marginTop:22,height:1,background:`linear-gradient(90deg,${col}55,rgba(0,212,255,.1),transparent)`}}/>
          </div>

          {mc?.sections?.length>0 ? (
            <>
              {mc.sections.map((sec,si)=>(
                <div key={si} style={{marginBottom:44}}>
                  <h2 onClick={()=>setOpenSec(openSec===si?null:si)}
                    style={{fontSize:15,fontWeight:700,color:col,marginBottom:14,cursor:'pointer',display:'flex',alignItems:'center',gap:10,userSelect:'none',transition:'opacity .2s'}}
                    onMouseEnter={e=>e.currentTarget.style.opacity='.75'}
                    onMouseLeave={e=>e.currentTarget.style.opacity='1'}>
                    <span style={{fontSize:9,display:'inline-block',transition:'transform .2s',transform:openSec===si?'rotate(90deg)':'rotate(0deg)'}}>▶</span>
                    {sec.heading}
                  </h2>
                  {(openSec===null||openSec===si)&&(
                    <div className="sec-body">
                      <p style={{fontSize:13,color:'rgba(232,244,248,.72)',lineHeight:1.95,maxWidth:720,whiteSpace:'pre-wrap',margin:0}}>{sec.body}</p>
                      {sec.code&&(
                        <div style={{margin:'22px 0',background:'rgba(0,0,0,.55)',border:'1px solid rgba(0,212,255,.12)',borderRadius:6,overflow:'hidden'}}>
                          <div style={{padding:'6px 18px',background:'rgba(0,212,255,.05)',borderBottom:'1px solid rgba(0,212,255,.08)',fontSize:8,color:'rgba(0,212,255,.35)',letterSpacing:2}}>TERMINAL · CODE</div>
                          <pre style={{margin:0,padding:'20px 22px',fontSize:11,color:'#00d4ff',lineHeight:1.9,overflowX:'auto',whiteSpace:'pre'}}>{sec.code}</pre>
                        </div>
                      )}
                      {sec.tip&&(
                        <div style={{margin:'18px 0',padding:'14px 20px',background:'rgba(191,90,242,.06)',border:'1px solid rgba(191,90,242,.2)',borderLeft:'3px solid #bf5af2',borderRadius:4,fontSize:12,color:'rgba(232,244,248,.7)',lineHeight:1.8}}>
                          <span style={{color:'#bf5af2',fontWeight:700,marginRight:8}}>💡</span>{sec.tip}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}

              {mc.keyPoints?.length>0&&(
                <div style={{margin:'44px 0 32px',padding:'24px 28px',background:`${col}08`,border:`1px solid ${col}1e`,borderRadius:8}}>
                  <div style={{fontSize:8,letterSpacing:3,color:`${col}77`,marginBottom:18}}>POINTS CLÉS</div>
                  {mc.keyPoints.map((pt,i)=>(
                    <div key={i} style={{display:'flex',gap:12,marginBottom:11,fontSize:12,color:'rgba(232,244,248,.8)',lineHeight:1.7}}>
                      <span style={{color,fontWeight:700,flexShrink:0}}>▸</span><span>{pt}</span>
                    </div>
                  ))}
                </div>
              )}

              {mc.exercise&&(
                <div style={{margin:'28px 0',padding:'24px 28px',background:'rgba(0,255,136,.04)',border:'1px solid rgba(0,255,136,.18)',borderLeft:'3px solid #00ff88',borderRadius:6}}>
                  <div style={{fontSize:8,letterSpacing:3,color:'#00ff8877',marginBottom:12}}>EXERCICE PRATIQUE</div>
                  <p style={{fontSize:12,color:'rgba(232,244,248,.75)',lineHeight:1.9,margin:0}}>{mc.exercise}</p>
                </div>
              )}
            </>
          ):(
            <div>
              <div style={{fontSize:10,color:`${col}55`,letterSpacing:2,marginBottom:28}}>CONTENU EN CHARGEMENT...</div>
              {[80,60,72,45,66].map((w,i)=>(
                <div key={i} style={{marginBottom:16,height:10,width:`${w}%`,background:`linear-gradient(90deg,rgba(0,212,255,.08) 0%,rgba(0,212,255,.14) 50%,rgba(0,212,255,.08) 100%)`,borderRadius:3,backgroundSize:'200% auto',animation:'shimmer 2s linear infinite',animationDelay:`${i*.15}s`}}/>
              ))}
            </div>
          )}

          {course.resources?.length>0&&(
            <div style={{marginTop:52,paddingTop:28,borderTop:'1px solid rgba(0,212,255,.07)'}}>
              <div style={{fontSize:8,letterSpacing:3,color:'rgba(0,212,255,.25)',marginBottom:16}}>RESSOURCES & OUTILS</div>
              <div style={{display:'flex',flexWrap:'wrap',gap:8}}>
                {course.resources.map((r,i)=>(
                  <span key={i} style={{fontSize:10,padding:'5px 13px',borderRadius:4,background:'rgba(0,212,255,.05)',border:'1px solid rgba(0,212,255,.14)',color:'rgba(0,212,255,.55)',transition:'all .2s',cursor:'default'}}>{r}</span>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function App(){
  const videoRef    = useRef(null)
  const canvasRef   = useRef(null)
  const graphRef    = useRef(null)
  const handsRef    = useRef(null)
  const landmarksRef= useRef(null)
  const cursorRef   = useRef({x:-1,y:-1})
  const rafRef      = useRef(null)
  const simSteps    = useRef(0)
  const lastDetect  = useRef(0)
  const gestureRef  = useRef({name:'',dur:0})
  const viewRef     = useRef({x:0,y:0,scale:1})
  const prevPalm    = useRef(null)
  const prevPinch   = useRef(null)
  const trailRef    = useRef([])
  const auroraRef   = useRef(0)

  const [camActive,   setCamActive]   = useState(true)
  const [gesture,     setGesture]     = useState('')
  const [handCount,   setHandCount]   = useState(0)
  const [selCourse,   setSelCourse]   = useState(null)
  const [readerOpen,  setReaderOpen]  = useState(false)
  const [stats,       setStats]       = useState({nodes:0,edges:0,density:'0.000'})

  useEffect(()=>{
    const canvas=canvasRef.current
    const W=window.innerWidth, H=window.innerHeight
    canvas.width=W; canvas.height=H

    const graph=createGraph(W,H)
    graphRef.current=graph
    const n=graph.nodes.length, e=graph.edges.length
    setStats({nodes:n,edges:e,density:(e/(n*(n-1)/2)).toFixed(3)})

    // Camera
    navigator.mediaDevices.getUserMedia({video:{facingMode:'user',width:W,height:H}})
      .then(stream=>{
        if(!videoRef.current) return
        videoRef.current.srcObject=stream
        videoRef.current.play().then(loadMP).catch(loadMP)
      }).catch(e=>console.warn('Camera:',e))

    function loadMP(){
      if(window.Hands){initHands();return}
      const s=document.createElement('script')
      s.src='https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands.js'
      s.onload=()=>setTimeout(initHands,400)
      s.onerror=()=>console.warn('MediaPipe failed')
      document.head.appendChild(s)
    }

    function initHands(){
      if(!window.Hands){setTimeout(initHands,100);return}
      const h=new window.Hands({locateFile:f=>`https://cdn.jsdelivr.net/npm/@mediapipe/hands/${f}`})
      h.setOptions({maxNumHands:1,modelComplexity:1,minDetectionConfidence:.65,minTrackingConfidence:.5})
      h.onResults(onResults)
      handsRef.current=h
    }

    function onResults(results){
      const lms=results.multiHandLandmarks
      if(lms?.length>0){
        const hand=lms[0]
        landmarksRef.current=hand
        setHandCount(lms.length)
        const W2=canvas.width, H2=canvas.height
        const tipX=(1-hand[8].x)*W2, tipY=hand[8].y*H2
        const palmX=(1-hand[0].x)*W2, palmY=hand[0].y*H2
        const pinchD=Math.hypot((hand[4].x-hand[8].x)*W2,(hand[4].y-hand[8].y)*H2)
        cursorRef.current={x:tipX,y:tipY}

        const fu=(tip,pip)=>hand[tip].y<hand[pip].y
        const idx=fu(8,6),mid=fu(12,10),ring=fu(16,14),pink=fu(20,18)
        const isPinch=pinchD<40
        let g=''
        if(isPinch)                         g='PINCH'
        else if(!idx&&!mid&&!ring&&!pink)   g='FIST'
        else if(idx&&!mid&&!ring&&!pink)    g='POINT'
        else if(idx&&mid&&!ring&&!pink)     g='PEACE'
        else if(idx&&mid&&ring&&!pink)      g='THREE'
        else if(idx&&mid&&ring&&pink)       g='OPEN'

        // FIST → pan
        if(g==='FIST'){
          const p=prevPalm.current
          if(p){viewRef.current.x+=palmX-p.x;viewRef.current.y+=palmY-p.y}
          prevPalm.current={x:palmX,y:palmY}
        } else prevPalm.current=null

        // PINCH → zoom
        if(g==='PINCH'){
          const pd=prevPinch.current
          if(pd!==null){
            const delta=pinchD-pd, factor=1+delta*.012
            const v=viewRef.current
            v.scale=Math.max(.3,Math.min(4,v.scale*factor))
            v.x=tipX-(tipX-v.x)*factor
            v.y=tipY-(tipY-v.y)*factor
          }
          prevPinch.current=pinchD
        } else prevPinch.current=null

        const gr=gestureRef.current
        if(g===gr.name){ gr.dur+=16; if(gr.dur>600){trigger(g,tipX,tipY);gr.dur=0} }
        else{gr.name=g;gr.dur=0}
        setGesture(g)
      } else {
        landmarksRef.current=null
        cursorRef.current={x:-1,y:-1}
        setHandCount(0); setGesture('')
        gestureRef.current={name:'',dur:0}
        prevPalm.current=null; prevPinch.current=null
      }
    }

    function trigger(g,x,y){
      if(g==='THREE'){viewRef.current={x:0,y:0,scale:1};return}
      if(g==='OPEN'){setSelCourse(null);setReaderOpen(false);return}
      if(g==='POINT'||g==='PEACE'){
        const graph=graphRef.current; if(!graph) return
        const v=viewRef.current
        const gx=(x-v.x)/v.scale, gy=(y-v.y)/v.scale
        let closest=null, minD=60/v.scale
        graph.nodes.forEach(n=>{const d=Math.hypot(n.x-gx,n.y-gy);if(d<minD){minD=d;closest=n}})
        if(closest) setSelCourse(closest.course)
      }
    }

    // Aurora canvas layer
    const auroraCanvas=document.getElementById('aurora-canvas')
    if(auroraCanvas){
      auroraCanvas.width=W; auroraCanvas.height=H
    }

    // RAF loop
    function loop(ts){
      auroraRef.current=ts
      const c=canvasRef.current; if(!c) return
      const ctx=c.getContext('2d')
      ctx.clearRect(0,0,c.width,c.height)

      const g=graphRef.current
      if(g){
        if(simSteps.current<450){runForce(g,c.width,c.height);simSteps.current++}
        render(ctx,g,cursorRef.current,selCourse?.id,viewRef.current,ts,trailRef)
      }
      const lms=landmarksRef.current
      if(lms) renderHand(ctx,lms,c.width,c.height,gestureRef.current.name)

      // Send to mediapipe
      const vid=videoRef.current
      if(handsRef.current&&vid&&vid.readyState>=2&&ts-lastDetect.current>33){
        lastDetect.current=ts
        handsRef.current.send({image:vid}).catch(()=>{})
      }
      rafRef.current=requestAnimationFrame(loop)
    }
    rafRef.current=requestAnimationFrame(loop)

    // Resize
    function onResize(){
      canvas.width=window.innerWidth; canvas.height=window.innerHeight
      graphRef.current=createGraph(window.innerWidth,window.innerHeight)
      simSteps.current=0
    }
    // Click
    function onClick(e){
      const g=graphRef.current; if(!g) return
      const rect=canvas.getBoundingClientRect()
      const mx=e.clientX-rect.left, my=e.clientY-rect.top
      const v=viewRef.current
      const gx=(mx-v.x)/v.scale, gy=(my-v.y)/v.scale
      let closest=null, minD=50/v.scale
      g.nodes.forEach(n=>{const d=Math.hypot(n.x-gx,n.y-gy);if(d<minD){minD=d;closest=n}})
      if(closest) setSelCourse(closest.course); else setSelCourse(null)
    }
    // Wheel
    function onWheel(e){
      e.preventDefault()
      const v=viewRef.current
      const rect=canvas.getBoundingClientRect()
      const mx=e.clientX-rect.left, my=e.clientY-rect.top
      const f=e.deltaY<0?1.1:.9
      v.scale=Math.max(.3,Math.min(4,v.scale*f))
      v.x=mx-(mx-v.x)*f; v.y=my-(my-v.y)*f
    }

    window.addEventListener('resize',onResize)
    canvas.addEventListener('click',onClick)
    canvas.addEventListener('wheel',onWheel,{passive:false})
    return()=>{
      if(rafRef.current) cancelAnimationFrame(rafRef.current)
      window.removeEventListener('resize',onResize)
      canvas.removeEventListener('click',onClick)
      canvas.removeEventListener('wheel',onWheel)
    }
  },[])

  return(
    <div style={{position:'fixed',inset:0,background:'#030609',overflow:'hidden',fontFamily:'"JetBrains Mono",monospace'}}>
      <style>{`
        @keyframes scan{0%{top:-2px}100%{top:100%}}
        @keyframes shimmer{0%{background-position:200% center}100%{background-position:-200% center}}
        @keyframes aurora{0%,100%{transform:translate(-10%,-20%) rotate(0deg) scale(1)}25%{transform:translate(5%,-30%) rotate(20deg) scale(1.1)}50%{transform:translate(15%,-10%) rotate(-15deg) scale(.95)}75%{transform:translate(-5%,5%) rotate(30deg) scale(1.05)}}
        @keyframes auroraB{0%,100%{transform:translate(10%,10%) rotate(0deg) scale(1)}33%{transform:translate(-15%,20%) rotate(-25deg) scale(1.15)}66%{transform:translate(20%,-5%) rotate(15deg) scale(.9)}}
        @keyframes pulse{0%,100%{opacity:.5;transform:scale(1)}50%{opacity:1;transform:scale(1.05)}}
        @keyframes fadein{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
        @keyframes bracketGlow{0%,100%{box-shadow:0 0 6px rgba(0,212,255,.3)}50%{box-shadow:0 0 16px rgba(0,212,255,.7)}}
        @keyframes floatNode{0%,100%{transform:translateY(0)}50%{transform:translateY(-4px)}}
      `}</style>

      {/* Aurora background layers */}
      <div style={{position:'absolute',inset:0,overflow:'hidden',pointerEvents:'none',zIndex:0}}>
        <div style={{position:'absolute',width:'70%',height:'60%',top:'10%',left:'15%',
          background:'radial-gradient(ellipse,rgba(0,212,255,.07) 0%,transparent 70%)',
          animation:'aurora 18s ease-in-out infinite',filter:'blur(40px)'}}/>
        <div style={{position:'absolute',width:'50%',height:'50%',top:'40%',left:'5%',
          background:'radial-gradient(ellipse,rgba(191,90,242,.05) 0%,transparent 70%)',
          animation:'auroraB 22s ease-in-out infinite',filter:'blur(50px)'}}/>
        <div style={{position:'absolute',width:'40%',height:'40%',top:'20%',right:'10%',
          background:'radial-gradient(ellipse,rgba(0,255,136,.04) 0%,transparent 70%)',
          animation:'aurora 26s ease-in-out infinite reverse',filter:'blur(45px)'}}/>
      </div>

      {/* Camera */}
      <video ref={videoRef} autoPlay muted playsInline style={{
        position:'absolute',inset:0,width:'100%',height:'100%',
        objectFit:'cover',transform:'scaleX(-1)',
        opacity:camActive?.62:0,transition:'opacity .6s ease',zIndex:1
      }}/>

      {/* Dark vignette overlay */}
      <div style={{position:'absolute',inset:0,zIndex:2,pointerEvents:'none',
        background:'radial-gradient(ellipse 80% 80% at 50% 50%,rgba(3,6,9,.25) 0%,rgba(3,6,9,.72) 100%)',
        boxShadow:'inset 0 0 180px rgba(0,0,0,.65)'}}/>

      {/* Graph canvas */}
      <canvas ref={canvasRef} style={{position:'absolute',inset:0,width:'100%',height:'100%',cursor:'crosshair',zIndex:3}}/>

      {/* ── HUD: Top-left branding ── */}
      <div style={{position:'absolute',top:28,left:28,zIndex:10,animation:'fadein .6s ease'}}>
        <div style={{
          fontSize:20,fontWeight:900,letterSpacing:10,
          background:'linear-gradient(90deg,#00d4ff,#bf5af2 60%,#00d4ff)',
          backgroundSize:'200% auto',
          WebkitBackgroundClip:'text',WebkitTextFillColor:'transparent',
          animation:'shimmer 4s linear infinite',
          filter:'drop-shadow(0 0 12px rgba(0,212,255,.5))',
          marginBottom:14,
        }}>SOC · ACADEMY</div>
        <div style={{fontSize:10,lineHeight:2.2,letterSpacing:1}}>
          {[['NOEUDS',stats.nodes],['CONNEXIONS',stats.edges],['DENSITÉ',stats.density]].map(([k,v])=>(
            <div key={k} style={{color:'rgba(0,212,255,.35)'}}>
              <span style={{color:'rgba(0,212,255,.18)',marginRight:6}}>◈</span>
              {v} <span style={{opacity:.5}}>{k}</span>
            </div>
          ))}
        </div>
      </div>

      {/* HUD brackets */}
      {[{top:18,left:18},{top:18,right:18,transform:'scaleX(-1)'},{bottom:18,left:18,transform:'scaleY(-1)'},{bottom:18,right:18,transform:'scale(-1)'}].map((s,i)=>(
        <div key={i} style={{position:'absolute',width:22,height:22,zIndex:10,animation:'bracketGlow 3s ease-in-out infinite',animationDelay:`${i*.4}s`,...s}}>
          <div style={{position:'absolute',top:0,left:0,width:10,height:2,background:'rgba(0,212,255,.5)'}}/>
          <div style={{position:'absolute',top:0,left:0,width:2,height:10,background:'rgba(0,212,255,.5)'}}/>
        </div>
      ))}

      {/* ── HUD: Toggle cam (center-top) ── */}
      <button onClick={()=>setCamActive(v=>!v)} style={{
        position:'absolute',top:28,left:'50%',transform:'translateX(-50%)',zIndex:10,
        background:'transparent',border:`1px solid rgba(0,212,255,${camActive?.55:.25})`,
        color:camActive?'#00d4ff':'rgba(0,212,255,.35)',
        padding:'6px 24px',borderRadius:20,fontSize:9,letterSpacing:3,cursor:'pointer',
        transition:'all .35s',
        boxShadow:camActive?'0 0 20px rgba(0,212,255,.18),inset 0 0 12px rgba(0,212,255,.06)':'none',
      }}>{camActive?'DÉSACTIVER':'ACTIVER'}</button>

      {/* ── HUD: Top-right gesture + zoom ── */}
      <div style={{position:'absolute',top:28,right:28,zIndex:10,textAlign:'right',animation:'fadein .6s ease'}}>
        {gesture&&(
          <div style={{
            fontSize:11,letterSpacing:3,marginBottom:6,
            color:gesture==='PINCH'?'#f5a623':gesture==='FIST'?'#00ff88':gesture==='THREE'?'#bf5af2':'#00d4ff',
            filter:`drop-shadow(0 0 8px currentColor)`,
            fontWeight:700,transition:'color .2s',
          }}>
            {gesture==='PINCH'?'🤏 ZOOM':gesture==='FIST'?'✊ PAN':gesture==='THREE'?'🖖 RESET':gesture}
          </div>
        )}
        {handCount>0&&<div style={{color:'rgba(0,212,255,.35)',fontSize:9,letterSpacing:2,marginBottom:4}}>{handCount} MAIN{handCount>1?'S':''}</div>}
        <ZoomDisplay viewRef={viewRef}/>
      </div>

      {/* ── HUD: Left gesture guide ── */}
      <div style={{
        position:'absolute',top:'50%',left:24,transform:'translateY(-50%)',
        zIndex:10,borderLeft:'1px solid rgba(0,212,255,.12)',paddingLeft:14,
        display:'flex',flexDirection:'column',gap:11,animation:'fadein .6s ease',
      }}>
        {[['☝️','POINT','SÉLECTION'],['✌️','PEACE','FOCUS'],['✊','FIST','PAN'],['🤏','PINCH','ZOOM'],['🖖','THREE','RESET'],['✋','OPEN','FERMER']].map(([icon,key,label])=>{
          const active=gesture===key
          return(
            <div key={key} style={{display:'flex',alignItems:'center',gap:8,fontSize:9,letterSpacing:1,transition:'all .2s',
              color:active?'#00d4ff':'rgba(0,212,255,.3)',
              transform:active?'translateX(4px)':'none',
              textShadow:active?'0 0 8px rgba(0,212,255,.6)':'none',
            }}>
              <span style={{fontSize:12}}>{icon}</span>
              <span style={{fontWeight:active?700:400,color:active?'#00d4ff':'rgba(0,212,255,.45)'}}>{key}</span>
              <span style={{opacity:.5,fontSize:8}}>— {label}</span>
            </div>
          )
        })}
      </div>

      {/* ── HUD: Bottom-left phase legend ── */}
      <div style={{position:'absolute',bottom:28,left:28,zIndex:10,display:'flex',flexDirection:'column',gap:8,animation:'fadein .8s ease'}}>
        {PHASE_COLORS.map((color,i)=>(
          <div key={i} style={{display:'flex',alignItems:'center',gap:10,fontSize:9,letterSpacing:1}}>
            <div style={{width:7,height:7,borderRadius:'50%',background:color,
              boxShadow:`0 0 8px ${color},0 0 2px ${color}`,animation:'pulse 2.5s ease-in-out infinite',
              animationDelay:`${i*.4}s`}}/>
            <span style={{color:`${color}88`}}>P{i} — {PHASE_NAMES[i]}</span>
          </div>
        ))}
      </div>

      {/* Scan line */}
      <div style={{position:'absolute',left:0,right:0,height:1,zIndex:5,pointerEvents:'none',
        background:'linear-gradient(90deg,transparent,rgba(0,212,255,.2) 30%,rgba(0,212,255,.5) 50%,rgba(0,212,255,.2) 70%,transparent)',
        animation:'scan 9s linear infinite',
      }}/>

      {/* ── Node preview card ── */}
      {selCourse&&!readerOpen&&(()=>{
        const c=selCourse, col=PHASE_COLORS[c.phase]
        return(
          <div style={{
            position:'absolute',bottom:28,right:28,zIndex:20,width:318,
            background:'rgba(4,8,18,.95)',border:`1px solid ${col}28`,borderRadius:8,
            backdropFilter:'blur(24px)',overflow:'hidden',
            boxShadow:`0 0 60px ${col}10,0 8px 32px rgba(0,0,0,.4)`,
            animation:'fadein .2s ease',
          }}>
            <div style={{height:2,background:`linear-gradient(90deg,${col},${col}44,transparent)`}}/>
            <div style={{padding:'18px 20px 16px'}}>
              <div style={{fontSize:8,letterSpacing:2,color:`${col}77`,marginBottom:8}}>{c.icon} PHASE {c.phase} — {PHASE_NAMES[c.phase]}</div>
              <div style={{fontSize:14,fontWeight:700,color:'#f0f8ff',marginBottom:4,lineHeight:1.3}}>{c.title}</div>
              <div style={{fontSize:10,color:'rgba(0,212,255,.4)',marginBottom:18,lineHeight:1.7}}>{c.tagline}</div>
              <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:6,paddingBottom:16,borderBottom:`1px solid ${col}14`,marginBottom:14}}>
                {[['MOD',c.modules?.length],['DUR',c.duration],['NIV',c.level?.slice(0,3).toUpperCase()],['PH',c.phase]].map(([k,v])=>(
                  <div key={k} style={{textAlign:'center'}}>
                    <div style={{fontSize:7,color:'rgba(0,212,255,.2)',letterSpacing:1,marginBottom:3}}>{k}</div>
                    <div style={{fontSize:13,fontWeight:700,color:col}}>{v}</div>
                  </div>
                ))}
              </div>
              <div style={{display:'flex',gap:8}}>
                <button onClick={()=>setReaderOpen(true)} style={{
                  flex:1,padding:'9px 0',borderRadius:4,cursor:'pointer',fontFamily:'inherit',
                  background:`linear-gradient(135deg,${col}22,${col}0a)`,border:`1px solid ${col}44`,
                  color:col,fontSize:9,fontWeight:700,letterSpacing:2,
                  boxShadow:`0 0 16px ${col}10`,transition:'all .2s',
                }}
                  onMouseEnter={e=>{e.currentTarget.style.background=`${col}28`}}
                  onMouseLeave={e=>{e.currentTarget.style.background=`linear-gradient(135deg,${col}22,${col}0a)`}}>
                  OUVRIR LE COURS
                </button>
                <button onClick={()=>setSelCourse(null)} style={{
                  padding:'9px 14px',borderRadius:4,cursor:'pointer',fontFamily:'inherit',
                  background:'transparent',border:'1px solid rgba(0,212,255,.14)',
                  color:'rgba(0,212,255,.35)',fontSize:9,letterSpacing:1,transition:'all .2s',
                }}>✕</button>
              </div>
            </div>
          </div>
        )
      })()}

      {/* ── Course Reader ── */}
      {selCourse&&readerOpen&&(
        <CourseReader course={selCourse} onClose={()=>{setReaderOpen(false);setSelCourse(null)}}/>
      )}
    </div>
  )
}
