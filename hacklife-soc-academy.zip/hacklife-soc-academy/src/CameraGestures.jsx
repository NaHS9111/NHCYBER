import React, { useEffect, useRef, useState } from 'react'

const CameraGestures = ({ onGesture, onExit }) => {
  const videoRef = useRef(null)
  const canvasRef = useRef(null)
  const [gesture, setGesture] = useState('')
  const [holdTime, setHoldTime] = useState(0)
  const [loading, setLoading] = useState(true)
  const gestureDurationRef = useRef(0)
  const lastGestureRef = useRef('')

  useEffect(() => {
    const initCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'user', width: 1280, height: 720 }
        })
        if (videoRef.current) {
          videoRef.current.srcObject = stream
          setLoading(false)
          startGestureDetection()
        }
      } catch (err) {
        console.error('Camera error:', err)
        alert('Erreur caméra - accès refusé')
        onExit()
      }
    }

    const startGestureDetection = () => {
      const script = document.createElement('script')
      script.src = 'https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands.js'
      script.async = true
      script.onerror = () => {
        console.error('Failed to load MediaPipe')
        alert('MediaPipe failed to load')
      }
      script.onload = () => {
        initHands()
      }
      document.head.appendChild(script)
    }

    const initHands = () => {
      if (!window.Hands) {
        setTimeout(initHands, 100)
        return
      }

      try {
        const hands = new window.Hands({
          locateFile: (file) => {
            return `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`
          }
        })

        hands.setOptions({
          maxNumHands: 2,
          modelComplexity: 1,
          minDetectionConfidence: 0.5,
          minTrackingConfidence: 0.5
        })

        hands.onResults(onResults)

        const camera = new window.Camera(videoRef.current, {
          onFrame: async () => {
            try {
              await hands.send({ image: videoRef.current })
            } catch (e) {
              console.error('Hand detection error:', e)
            }
          },
          width: 1280,
          height: 720
        })

        camera.start()
      } catch (e) {
        console.error('Hands init error:', e)
      }
    }

    const onResults = (results) => {
      const canvas = canvasRef.current
      if (!canvas) return

      const ctx = canvas.getContext('2d')

      // Clear canvas
      ctx.fillStyle = 'rgba(0, 0, 0, 0.1)'
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      // Draw hand landmarks and connections
      if (results.multiHandLandmarks) {
        results.multiHandLandmarks.forEach((landmarks, handIdx) => {
          drawHand(ctx, landmarks, canvas.width, canvas.height, handIdx)
        })

        analyzeGesture(results.multiHandLandmarks)
      }
    }

    const drawHand = (ctx, landmarks, width, height, handIdx) => {
      const connections = [
        [0, 1], [1, 2], [2, 3], [3, 4],
        [0, 5], [5, 6], [6, 7], [7, 8],
        [5, 9], [9, 10], [10, 11], [11, 12],
        [9, 13], [13, 14], [14, 15], [15, 16],
        [13, 17], [17, 18], [18, 19], [19, 20],
        [0, 17]
      ]

      const colors = ['#00d4ff', '#ff00ff']
      const color = colors[handIdx % colors.length]

      // Draw connections
      ctx.strokeStyle = color
      ctx.lineWidth = 2
      ctx.globalAlpha = 0.7

      for (const [start, end] of connections) {
        const s = landmarks[start]
        const e = landmarks[end]
        ctx.beginPath()
        ctx.moveTo(s.x * width, s.y * height)
        ctx.lineTo(e.x * width, e.y * height)
        ctx.stroke()
      }

      // Draw points
      ctx.globalAlpha = 1
      landmarks.forEach((landmark, idx) => {
        const x = landmark.x * width
        const y = landmark.y * height

        // Glow
        ctx.fillStyle = color + '33'
        ctx.beginPath()
        ctx.arc(x, y, 10, 0, Math.PI * 2)
        ctx.fill()

        // Point
        ctx.fillStyle = color
        ctx.beginPath()
        ctx.arc(x, y, 5, 0, Math.PI * 2)
        ctx.fill()
      })

      ctx.globalAlpha = 1
    }

    const analyzeGesture = (handsArray) => {
      if (!handsArray || handsArray.length === 0) {
        setGesture('')
        setHoldTime(0)
        return
      }

      const landmarks = handsArray[0]

      const fingerUp = (lm, tip, pip) => lm[tip].y < lm[pip].y

      const index = fingerUp(landmarks, 8, 6)
      const middle = fingerUp(landmarks, 12, 10)
      const ring = fingerUp(landmarks, 16, 14)
      const pinky = fingerUp(landmarks, 20, 18)

      let currentGesture = ''

      if (!index && !middle && !ring && !pinky) {
        currentGesture = 'FIST'
      } else if (index && middle && !ring && !pinky) {
        currentGesture = 'PEACE'
      } else if (index && !middle && !ring && !pinky) {
        currentGesture = 'POINT'
      } else if (index && middle && ring && pinky) {
        currentGesture = 'OPEN'
      }

      if (currentGesture === lastGestureRef.current) {
        gestureDurationRef.current += 16
        setHoldTime(Math.round(gestureDurationRef.current / 100) / 10)
      } else {
        lastGestureRef.current = currentGesture
        gestureDurationRef.current = 0
        setHoldTime(0)
      }

      setGesture(currentGesture)

      if (currentGesture && gestureDurationRef.current > 800) {
        onGesture(currentGesture)
        gestureDurationRef.current = 0
        lastGestureRef.current = ''
      }
    }

    initCamera()
  }, [onGesture, onExit])

  useEffect(() => {
    const canvas = canvasRef.current
    if (canvas) {
      canvas.width = 1280
      canvas.height = 720
    }
  }, [])

  return (
    <div className="relative w-full h-screen bg-black overflow-hidden">
      {loading && (
        <div className="absolute inset-0 flex items-center justify-center z-50 bg-obsidian">
          <div className="text-center">
            <div className="text-4xl font-bold text-cyan-400 mb-4">INITIALIZING CAM...</div>
            <div className="text-cyan-300">Accès caméra requis</div>
          </div>
        </div>
      )}

      {/* Video */}
      <video
        ref={videoRef}
        className="absolute inset-0 w-full h-full object-cover"
        style={{ transform: 'scaleX(-1)' }}
      />

      {/* Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
        style={{ transform: 'scaleX(-1)' }}
      />

      {/* HUD */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="scan-line" />
        <div className="absolute inset-0 hud-grid opacity-5" />
        <div className="absolute top-8 left-8 w-16 h-16 hud-bracket" />
        <div className="absolute bottom-8 right-8 w-16 h-16 hud-bracket" />
      </div>

      {/* Gesture Display */}
      {gesture && (
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-30 text-center">
          <div className="text-9xl font-black" style={{
            color: '#00d4ff',
            textShadow: '0 0 40px rgba(0,212,255,1), 0 0 80px rgba(0,212,255,0.6)'
          }}>
            {gesture}
          </div>
          <div className="text-lg text-cyan-300 font-mono mt-4">
            Hold {Math.max(0, (0.8 - holdTime).toFixed(1))}s
          </div>
        </div>
      )}

      {/* Controls */}
      <button
        onClick={onExit}
        className="absolute top-8 right-8 z-20 px-6 py-3 bg-obsidian border-2 border-cyan-500 text-cyan-400 rounded font-mono font-bold hover:bg-cyan-500/10"
        style={{ boxShadow: '0 0 20px rgba(0,212,255,0.3)' }}
      >
        ESC
      </button>

      {/* Info */}
      <div className="absolute bottom-8 left-8 z-20 text-cyan-400 font-mono text-sm">
        <div>✌️ PEACE = Toggle</div>
        <div>✋ OPEN = Next</div>
        <div>✊ FIST = Home</div>
        <div>☝️ POINT = Search</div>
      </div>
    </div>
  )
}

export default CameraGestures
